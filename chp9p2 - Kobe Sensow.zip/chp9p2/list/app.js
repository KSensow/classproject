var createError = require('http-errors');
var express = require('express');
var path = require('path');
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./routes/index');
var usersRouter = require('./routes/users');

var mongoose = require("mongoose");
const { appendFile } = require('fs');
mongoose.connect("mongodb://localhost/mydb_test");

var listSchema = mongoose.Schema({
 text : String
});

var List = mongoose.model("elements", listSchema);

var app = express();

// view engine setup
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'jade');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);

// creating a new element in the list
// ✅ New style with async/await
app.post("/add", async (req, res) => {
  try {
    const doc = await List.create({ text: req.body.text });
    res.json(doc);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.post("/list", async (req, res) => {
  try {
    const doc = await List.create({ text: req.body.text });
    res.json(doc);
  } catch (err) {
    res.status(500).send(err.message);
  }
});

app.get("/list", function(req, res) {
  List.find({})
    .then(elements => {
      res.json({ elements: elements });
    })
    .catch(err => {
      // Handle the error (e.g., log it and send an error response)
      console.error(err);
      res.status(500).json({ message: "Internal server error" });
    });
});

// modifying an element in the list
app.put("/list", (req, res, next) => {
  const { id, text } = req.body;

  List.updateOne({ _id: id }, { text })
    .exec()
    .then(result => {
      res.send(); // or res.json(result) if you want to return something
    })
    
    .catch(err => {
      console.error(err);
      res.status(500).json({ message: "Internal server error" });
    });
});

app.delete("/list", async function (req, res) {
  var id = req.body.id;
  console.log(req.body.id);
  await List.deleteOne({ _id: id }).exec(); // don't forget exec()!
  res.send(); // close the connection to the browser
});

// catch 404 and forward to error handler
app.use(function(req, res, next) {
  next(createError(404));
});

// error handler
app.use(function(err, req, res, next) {
  // set locals, only providing error in development
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? 
  err : {};
  // render the error page
  res.status(err.status || 500);
  res.render('error');
});

const port = 3000;
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});

module.exports = app;